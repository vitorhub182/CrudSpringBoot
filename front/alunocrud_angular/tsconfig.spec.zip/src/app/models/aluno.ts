export interface Aluno {
    id: number;
    first_name: string;
    last_name: string;
    date_birth: Date;
    created: Date;
    lastModified: Date;
}
